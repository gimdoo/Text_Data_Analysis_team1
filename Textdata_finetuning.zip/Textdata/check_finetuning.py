from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

FT_API_KEY = os.getenv("OPENAI_FINE_TUNE_KEY")
if not FT_API_KEY:
    raise ValueError("OPENAI_FINE_TUNE_KEY 가 .env에 설정되어 있지 않습니다.")

ft_client = OpenAI(api_key=FT_API_KEY)

JOB_ID = "ftjob-ftHr3ViDFF17nSgaP8yxBHGc"

job = ft_client.fine_tuning.jobs.retrieve(JOB_ID)

print("status:", job.status)
print("fine_tuned_model:", job.fine_tuned_model)
