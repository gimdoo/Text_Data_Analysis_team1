from openai import OpenAI
from dotenv import load_dotenv
import os

# 1) .env 불러오기
load_dotenv()

FT_API_KEY = os.getenv("OPENAI_FINE_TUNE_KEY")
if not FT_API_KEY:
    raise ValueError("OPENAI_FINE_TUNE_KEY 가 .env에 설정되어 있지 않습니다.")

# 2) 파인튜닝 전용 클라이언트
ft_client = OpenAI(api_key=FT_API_KEY)

# 3) 학습 데이터 파일 업로드
jsonl_path = "contract_finetune.jsonl"  # 파일 이름/경로 확인!

upload_resp = ft_client.files.create(
    file=open(jsonl_path, "rb"),
    purpose="fine-tune"
)

training_file_id = upload_resp.id
print("업로드 완료. training_file_id:", training_file_id)

# 4) 파인튜닝 Job 생성
job = ft_client.fine_tuning.jobs.create(
    training_file=training_file_id,
    model="gpt-4.1-mini-2025-04-14", #경량 모델 사용
)

print("파인튜닝 생성 완료!")
print("job_id:", job.id)
print("status:", job.status)
