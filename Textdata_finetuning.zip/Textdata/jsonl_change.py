import pandas as pd
import json

# 1) 엑셀 불러오기
df = pd.read_excel(r"C:\Users\cheri\OneDrive\문서\Textdata\contract_clauses_easy.xlsx")


# 2) 필요한 컬럼 이름(파일 확인 후 맞추기)
#    아래 컬럼 이름이 정확한지 확인해줘!
#    original_clause = 원문 조항
#    easy_explanation = 쉬운 설명
df = df[['original_clause', 'easy_explanation']]

# 3) 빈값 제거 (혹시 모를 오류 방지)
df = df.dropna(subset=['original_clause', 'easy_explanation'])

# 4) system 프롬프트 (persona + instruction + format + audience 구조 모두 포함)
SYSTEM_PROMPT = (
    "당신은 계약서를 쉽게 설명하는 전문가입니다. "
    "존댓말을 사용하고, 핵심 내용을 1~4문장으로 요약하세요."
)

# 5) JSONL로 저장
output_path = "contract_finetune.jsonl"

with open(output_path, "w", encoding="utf-8") as f:
    for _, row in df.iterrows():
        item = {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": row['original_clause']},
                {"role": "assistant", "content": row['easy_explanation']},
            ]
        }
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

print(" JSONL 생성 완료", output_path)
