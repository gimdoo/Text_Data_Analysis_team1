from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

FT_API_KEY = os.getenv("OPENAI_FINE_TUNE_KEY")
if not FT_API_KEY:
    raise ValueError("OPENAI_FINE_TUNE_KEY 가 .env에 설정되어 있지 않습니다.")

ft_client = OpenAI(api_key=FT_API_KEY)

FINETUNED_MODEL = "ft:gpt-4.1-mini-2025-04-14:dbdbdeep::CiuSaiDu"

test_clause = """
제3조(근로시간) ① 근로시간은 1일 8시간, 1주 40시간을 원칙으로 한다. 
② 회사의 사정에 따라 근로자는 연장근로를 할 수 있다.
"""

resp = ft_client.chat.completions.create(
    model=FINETUNED_MODEL,
    messages=[
        {
            "role": "system",
            "content": (
                "당신은 계약서를 쉽게 설명하는 도우미입니다. "
                "사용자가 이해하기 쉬운 문장으로 바꾸어 설명하되 "
                "반드시 1~4문장으로 핵심만 요약해서 말하세요."
            )
        },
        {
            "role": "user",
            "content": test_clause
        }
    ]
)

print("=== 모델 출력 ===")
print(resp.choices[0].message.content)
